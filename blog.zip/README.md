# Blog

> vue + koa blog

Before starting the item, make sure that you have installed MongoDB.

## Quick start

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev && node app.js

# build for production with minification
  npm run build

  ## then uncomment
    // app.use(historyApiFallback()); 
    // app.use(serve(path.resolve('dist'))); 
  ## at app.js

  ## start backend  
  node app.js
  ## it'll load at localhost:3389

```