<template>
  <div id="edit-about-box">
  </div>
</template>
<script>
	export default {
		data () {
			return {

			};
		},
		methods:{
		},
		mounted() {
		},
		computed:{
		}
	}
</script>
<style lang="stylus" scoped>
div#edit-about-box
	background #fff
	margin 10px
	width 100%
</style>