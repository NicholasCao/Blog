> 个人博客的搭建差不多进入尾声，可能还存在一些bug，但我已迫不及待得想写一篇博文。。。
> 
```javascript
console.log("Hello, world")
```
## bolg后台展示
![](http://nicholas-image.oss-cn-shenzhen.aliyuncs.com/18-8-4/85224149.jpg)

![](http://nicholas-image.oss-cn-shenzhen.aliyuncs.com/18-8-4/7945191.jpg)


## 用到的一些技术栈

vue ->前端
koa ->后端
jsonwebtoken ->auth用户验证
MongoDB ->数据库储存博文等
Axios ->api请求
element-ui -> vue的ui框架用于后台管理界面

## 初衷
搭建这个博客的初衷是想用自己所学知识写一个项目
另外通过博文记录自己学习前端的历程，分享一下自己所学，让其他初学者少走一些弯路

## 关于样式
我没有想到的是，在开发的过程中我最大的困难的是写样式，这也让我意识到自己的短板

Blog的样式随便写了点，样式虽说自己磕磕碰碰的写完了，但我自己还是不太满意
后续应该会更新2.0版本😆


## 后续
后续可能会开发留言墙或者评论功能
如果你有更好的idea，也联系我！
另外，域名还在实名认证和备案，后面就变成nicholasc.cn，敬请期待!
## 最后
Blog的搭建详情将在下篇博文
If you are satisfied with what I wrote, plz [follow](https://github.com/NicholasCao) me in Github.
也欢迎你的 [Star](https://github.com/NicholasCao/Blog) or [Folk](https://github.com/NicholasCao/Blog)
By the way，联系方式在底部
